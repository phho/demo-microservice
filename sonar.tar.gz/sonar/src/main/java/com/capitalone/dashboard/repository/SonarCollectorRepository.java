package com.capitalone.dashboard.repository;

import com.capitalone.dashboard.model.SonarCollector;

public interface SonarCollectorRepository extends BaseCollectorRepository<SonarCollector> {
}
