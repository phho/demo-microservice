cf cups gemfire -p '{"locatorHost":"192.168.11.1","locatorPort":"10334", "RestEndpoint":"http://192.168.11.1:8888/gemfire-api/v1/"}'
