Source: [American Community Survey](http://factfinder2.census.gov/), 2012 5-year estimate.
