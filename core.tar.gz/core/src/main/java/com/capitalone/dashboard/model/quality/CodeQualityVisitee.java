package com.capitalone.dashboard.model.quality;

public interface CodeQualityVisitee {

    void accept(CodeQualityVisitor visitor);
}
