package com.capitalone.dashboard.model;

public enum UserRole {

	ROLE_USER,
	ROLE_ADMIN,
	ROLE_API;
}