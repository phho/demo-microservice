package com.capitalone.dashboard.model;

public enum PipelineStageType {
	BUILD, COMMIT, DEPLOY
}