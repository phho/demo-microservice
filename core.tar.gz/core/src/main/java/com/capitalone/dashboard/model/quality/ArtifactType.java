package com.capitalone.dashboard.model.quality;

public enum ArtifactType {
    junit, findbugs, jacoco, pmd, checkstyle;
}
