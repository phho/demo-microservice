package com.capitalone.dashboard.model;

public enum PerformanceMetricStatus {
    OK, WARNING, CRITICAL
}
