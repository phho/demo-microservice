package io.pivotal.demo.sko;

public enum RegionName {

	PoS, Suspect, Transaction;

}
