/**
 * Houses artifacts are responsible for collecting data from source systems and putting them into MongoDB, based on the data model.
 * 
 * @author KFK884
 *
 */
package com.capitalone.dashboard.collector;