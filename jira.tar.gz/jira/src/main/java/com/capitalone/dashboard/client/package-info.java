/**
 * Library which contains all local client and business logic containers that speak
 * to source systems and orchestrates those connections
 *
 * @author KFK884
 *
 */
package com.capitalone.dashboard.client;
