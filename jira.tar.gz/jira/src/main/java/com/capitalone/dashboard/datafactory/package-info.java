/**
 * Houses artifacts that help build data responses from source systems.  There are sub packages in this library which are specific to their source systems.
 * 
 * @author KFK884
 *
 */
package com.capitalone.dashboard.datafactory;