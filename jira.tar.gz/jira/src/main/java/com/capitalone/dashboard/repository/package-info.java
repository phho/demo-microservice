/**
 * Houses Spring Boot repository configurations.
 * 
 * @author KFK884
 *
 */
package com.capitalone.dashboard.repository;