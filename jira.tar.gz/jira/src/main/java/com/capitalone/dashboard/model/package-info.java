/**
 * Houses Spring data model configurations.
 * 
 * @author KFK884
 *
 */
package com.capitalone.dashboard.model;