/**
 * Houses local use utilities for this collector app.
 * 
 * @author KFK884
 *
 */
package com.capitalone.dashboard.util;