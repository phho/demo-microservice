/**
 * Houses artifacts that help build data responses from Jira source system.
 * 
 * @author KFK884
 *
 */
package com.capitalone.dashboard.datafactory.jira;