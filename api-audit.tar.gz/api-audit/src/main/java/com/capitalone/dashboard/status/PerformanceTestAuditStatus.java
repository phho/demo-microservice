package com.capitalone.dashboard.status;

public enum PerformanceTestAuditStatus {
    PERF_RESULT_AUDIT_FAIL,
    PERF_RESULT_AUDIT_MISSING,
    PERF_RESULT_AUDIT_OK
}
