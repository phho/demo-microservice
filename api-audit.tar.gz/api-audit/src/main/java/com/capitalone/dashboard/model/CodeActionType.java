package com.capitalone.dashboard.model;

public enum CodeActionType {
    Commit,
    Review,
    PRCreate,
    PRMerge
}