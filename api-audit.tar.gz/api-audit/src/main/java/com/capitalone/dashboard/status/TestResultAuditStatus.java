package com.capitalone.dashboard.status;

public enum TestResultAuditStatus {
    TEST_RESULT_AUDIT_FAIL,
    TEST_RESULT_AUDIT_MISSING,
    TEST_RESULT_MISSING, TEST_RESULT_AUDIT_OK
}
