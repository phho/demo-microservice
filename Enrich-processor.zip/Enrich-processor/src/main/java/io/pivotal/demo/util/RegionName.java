package io.pivotal.demo.util;

public enum RegionName {

	PoS, Suspect, Transaction;

}
