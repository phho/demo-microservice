package com.capitalone.dashboard.repository;

import com.capitalone.dashboard.model.HudsonJob;


public interface HudsonJobRepository extends JobRepository<HudsonJob> {

}
